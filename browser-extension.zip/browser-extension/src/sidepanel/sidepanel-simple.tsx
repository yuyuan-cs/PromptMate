/**
 * 简化调试版本的SidePanel
 */

import * as React from 'react';
import * as ReactDOM from 'react-dom/client';
import { Button } from '../components/ui/button';
import { PromptEditView } from '../components/PromptEditView';

interface SidePanelProps {}

const SidePanel: React.FC<SidePanelProps> = () => {
  console.log('🔵 简化版SidePanel 开始渲染');
  
  const [currentView, setCurrentView] = React.useState<'list' | 'edit'>('list');
  const [editingPrompt, setEditingPrompt] = React.useState(null);

  const handleCreatePrompt = React.useCallback(() => {
    console.log('🟢 新建按钮被点击！');
    alert('调试：新建按钮被点击，即将切换到编辑视图');
    setCurrentView('edit');
    setEditingPrompt(null);
    console.log('🟢 视图已切换到 edit');
  }, []);

  const handleBack = React.useCallback(() => {
    console.log('🔴 返回按钮被点击');
    setCurrentView('list');
    setEditingPrompt(null);
  }, []);

  console.log('🔵 当前视图状态:', currentView);

  return (
    <div style={{ padding: '20px', background: '#f0f0f0', minHeight: '100vh' }}>
      <div style={{ background: 'yellow', padding: '10px', marginBottom: '20px', border: '2px solid orange' }}>
        <h2>🐛 调试信息面板</h2>
        <p><strong>当前视图:</strong> {currentView}</p>
        <p><strong>编辑提示词:</strong> {editingPrompt ? '有' : '无'}</p>
        <p><strong>渲染时间:</strong> {new Date().toLocaleTimeString()}</p>
      </div>

      {currentView === 'list' ? (
        <div style={{ background: 'lightblue', padding: '20px', border: '2px solid blue' }}>
          <h3>📝 提示词列表视图</h3>
          <p>如果你能看到这个蓝色区域，说明基本渲染正常</p>
          <Button 
            onClick={handleCreatePrompt} 
            style={{ 
              background: 'green', 
              color: 'white', 
              padding: '10px 20px',
              fontSize: '16px',
              border: '2px solid darkgreen'
            }}
          >
            🆕 新建提示词 (调试版)
          </Button>
        </div>
      ) : currentView === 'edit' ? (
        <div style={{ background: 'lightcoral', padding: '20px', border: '2px solid red' }}>
          <h3>✏️ 编辑视图</h3>
          <p>如果你能看到这个红色区域，说明视图切换成功</p>
          <Button 
            onClick={handleBack} 
            style={{ 
              background: 'red', 
              color: 'white', 
              marginBottom: '10px',
              padding: '10px 20px',
              fontSize: '16px'
            }}
          >
            ⬅️ 返回列表
          </Button>
          
          <div style={{ background: 'white', padding: '10px', border: '2px solid red', marginTop: '10px' }}>
            <p><strong>PromptEditView 渲染测试:</strong></p>
            <div style={{ border: '1px dashed gray', padding: '5px' }}>
              <PromptEditView
                isVisible={true}
                prompt={editingPrompt}
                categories={[]}
                onBack={handleBack}
                onClose={handleBack}
                onSave={() => console.log('保存被调用')}
                onUpdate={() => console.log('更新被调用')}
              />
            </div>
          </div>
        </div>
      ) : (
        <div style={{ background: 'orange', padding: '20px' }}>
          <h3>❓ 未知视图状态</h3>
          <p>当前视图: {currentView}</p>
        </div>
      )}
    </div>
  );
};

// 渲染到DOM
const container = document.getElementById('root');
if (container) {
  console.log('🔵 找到root容器，开始渲染React应用');
  const root = ReactDOM.createRoot(container);
  root.render(<SidePanel />);
  console.log('🔵 React应用渲染完成');
} else {
  console.error('❌ 未找到root容器！');
  alert('错误：未找到root容器！');
}

export default SidePanel;
