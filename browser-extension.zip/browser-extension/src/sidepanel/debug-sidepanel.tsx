/**
 * 调试版本的SidePanel - 用于定位空白屏幕问题
 */

import * as React from 'react';
import { Button } from '../components/ui/button';
import { PromptEditView } from '../components/PromptEditView';

interface DebugSidePanelProps {}

const DebugSidePanel: React.FC<DebugSidePanelProps> = () => {
  console.log('🔵 DebugSidePanel 开始渲染');
  
  const [currentView, setCurrentView] = React.useState<'list' | 'edit'>('list');
  const [editingPrompt, setEditingPrompt] = React.useState(null);

  const handleCreatePrompt = React.useCallback(() => {
    console.log('🟢 新建按钮被点击！');
    alert('调试：新建按钮被点击，即将切换到编辑视图');
    setCurrentView('edit');
    setEditingPrompt(null);
    console.log('🟢 视图已切换到 edit');
  }, []);

  const handleBack = React.useCallback(() => {
    console.log('🔴 返回按钮被点击');
    setCurrentView('list');
    setEditingPrompt(null);
  }, []);

  console.log('🔵 当前视图状态:', currentView);

  return (
    <div style={{ padding: '20px', background: '#f0f0f0', minHeight: '100vh' }}>
      <div style={{ background: 'yellow', padding: '10px', marginBottom: '20px' }}>
        <h2>调试信息</h2>
        <p>当前视图: {currentView}</p>
        <p>编辑提示词: {editingPrompt ? '有' : '无'}</p>
      </div>

      {currentView === 'list' ? (
        <div style={{ background: 'lightblue', padding: '20px' }}>
          <h3>提示词列表视图</h3>
          <Button onClick={handleCreatePrompt} style={{ background: 'green', color: 'white' }}>
            新建提示词 (调试版)
          </Button>
        </div>
      ) : currentView === 'edit' ? (
        <div style={{ background: 'lightcoral', padding: '20px' }}>
          <h3>编辑视图</h3>
          <Button onClick={handleBack} style={{ background: 'red', color: 'white', marginBottom: '10px' }}>
            返回列表
          </Button>
          <div style={{ background: 'white', padding: '10px', border: '2px solid red' }}>
            <p>PromptEditView 应该在这里渲染:</p>
            <PromptEditView
              isVisible={true}
              prompt={editingPrompt}
              categories={[]}
              onBack={handleBack}
              onClose={handleBack}
              onSave={() => {}}
              onUpdate={() => {}}
            />
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default DebugSidePanel;
